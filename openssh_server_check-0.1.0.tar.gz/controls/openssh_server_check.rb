# Profile: openssh_server_check

title 'OpenSSH Server Configuration'

# Check OpenSSH server version and service status
control 'openssh-server-check' do
  impact 1.0
  title 'Verify OpenSSH server version and service status'
  tag cve: 'CVE-2024-6387'
  desc 'regreSSHion: Remote Unauthenticated Code Execution Vulnerability in OpenSSH server'

  # Unix-based systems
  if os.unix?
    describe package('openssh-server') do
      it { should be_installed }
      its('version') { should_not be < '4.4' }
      its('version') { should_not be >= '8.5' }
      its('version') { should be < '9.8' }
    end
    describe service('sshd') do
      it { should be_running }
    end

  # Windows systems
  elsif os.windows?
    describe package('OpenSSH.Server') do
      it { should be_installed }
      # Adjust version comparison for Windows package versioning format
      its('version') { should_not be < '4.4' }
      its('version') { should_not be >= '8.5' }
      its('version') { should be < '9.8' }
    end
    describe service('sshd') do
      it { should be_installed }
      it { should be_running }
    end

  else
    # Unsupported operating system
    describe 'Operating System' do
      it { skip 'This control is not supported on your operating system' }
    end
  end
end

